setwd("E:/Tugas_DM/Tugas_kelompok")
dataset <- read.csv("iris.csv", sep = ";")
library(C50)
library(datasets)
data("iris")
dataset = iris
str(dataset)
View(dataset)

model <- C5.0(Species ~., data=dataset)
model
summary(model)
plot(model)
datatesting <- dataset[,1:4]
View(datatesting)
predictions <- predict(model, datatesting)
table(predictions, dataset$Species)

